import { useState, useEffect, useRef } from "react";

function GradientHunter() {

  const COLORS = [
    { name: "Sea Green", value: "seagreen", key: "Q" },
    { name: "Tan", value: "tan", key: "W" },
    { name: "Indigo", value: "indigo", key: "E" },
    { name: "Maroon", value: "maroon", key: "R" },
    { name: "Navy", value: "navy", key: "T" },
  ];

  const [orbs, setOrbs] = useState([]);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [level, setLevel] = useState(1);
  const [lives, setLives] = useState(5);
  const [paused, setPaused] = useState(false);
  const [message, setMessage] = useState("");
  const [shake, setShake] = useState(false);
  const [highScore, setHighScore] = useState(
    Number(localStorage.getItem("hunterHigh")) || 0
  );

  const gameRef = useRef();
  const spawnRef = useRef();
  const idRef = useRef(0);

  const spawnSpeed = Math.max(800 - level * 60, 250);
  const fallSpeed = Math.max(4000 - level * 300, 1200);

  const randomColor = () =>
    COLORS[Math.floor(Math.random() * COLORS.length)];

  const spawnOrb = () => {

    const color = randomColor();

    const orb = {
      id: idRef.current++,
      color,
      x: Math.random() * 80 + 10,
      speed: fallSpeed,
    };

    setOrbs((prev) => [...prev, orb]);
  };

  useEffect(() => {

    spawnRef.current = setInterval(() => {
      if (!paused && lives > 0) spawnOrb();
    }, spawnSpeed);

    return () => clearInterval(spawnRef.current);

  }, [level, paused, lives]);

  const removeOrb = (id) => {
    setOrbs((prev) => prev.filter((o) => o.id !== id));
  };

  const success = () => {

    setScore((s) => s + 10 * combo);
    setCombo((c) => c + 1);
    setMessage("🔥 Combo!");

    setTimeout(() => setMessage(""), 700);

  };

  const fail = () => {

    setLives((l) => l - 1);
    setCombo(1);
    setShake(true);
    setMessage("❌ Miss");

    setTimeout(() => {
      setShake(false);
      setMessage("");
    }, 600);

  };

  const handlePress = (colorName) => {

    const target = orbs.find((o) => o.color.name === colorName);

    if (target) {

      removeOrb(target.id);
      success();

    } else {

      fail();

    }
  };

  useEffect(() => {

    const keyHandler = (e) => {

      const key = e.key.toUpperCase();

      const found = COLORS.find((c) => c.key === key);

      if (found) handlePress(found.name);

      if (key === "P") setPaused((p) => !p);

    };

    window.addEventListener("keydown", keyHandler);

    return () => window.removeEventListener("keydown", keyHandler);

  }, [orbs]);

  useEffect(() => {

    if (score > highScore) {

      setHighScore(score);
      localStorage.setItem("hunterHigh", score);

    }

    if (score > level * 120) {

      setLevel((l) => l + 1);
      setMessage("🚀 Level Up!");

      setTimeout(() => setMessage(""), 900);

    }

  }, [score]);

  useEffect(() => {

    if (lives <= 0) {

      setPaused(true);
      setMessage("💀 Game Over");

    }

  }, [lives]);

  const resetGame = () => {

    setScore(0);
    setCombo(1);
    setLevel(1);
    setLives(5);
    setPaused(false);
    setOrbs([]);
    setMessage("");

  };

  return (
    <>
      <style>{`

      .container{

        height:100vh;
        background:linear-gradient(135deg,#101522,#1e293b);
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:flex-start;
        font-family:Poppins,sans-serif;
        color:white;
        overflow:hidden;

      }

      h1{

        margin-top:20px;
        font-size:2.8rem;
        letter-spacing:2px;

      }

      .stats{

        display:flex;
        gap:30px;
        margin-top:10px;
        font-size:18px;

      }

      .game{

        position:relative;
        width:100%;
        height:60vh;
        margin-top:20px;
        overflow:hidden;
        border-top:2px solid rgba(255,255,255,0.2);

      }

      .orb{

        width:60px;
        height:60px;
        border-radius:50%;
        position:absolute;
        top:-70px;
        animation:fall linear forwards;

      }

      @keyframes fall{

        from{top:-70px;}
        to{top:100%;}

      }

      .buttons{

        margin-top:30px;
        display:flex;
        gap:18px;
        flex-wrap:wrap;
        justify-content:center;

      }

      button{

        border:none;
        padding:12px 18px;
        border-radius:30px;
        color:white;
        font-weight:bold;
        font-size:15px;
        cursor:pointer;
        transition:0.3s;
        box-shadow:0 6px 18px rgba(0,0,0,0.4);

      }

      button:hover{

        transform:scale(1.1);

      }

      .message{

        margin-top:15px;
        font-size:20px;
        font-weight:bold;
        min-height:30px;

      }

      .shake{

        animation:shake 0.4s;

      }

      @keyframes shake{

        0%{transform:translateX(0);}
        25%{transform:translateX(-6px);}
        50%{transform:translateX(6px);}
        75%{transform:translateX(-4px);}
        100%{transform:translateX(0);}

      }

      .controls{

        margin-top:15px;
        display:flex;
        gap:15px;

      }

      .panel{

        margin-top:15px;
        font-size:14px;
        opacity:0.8;
        text-align:center;

      }

      `}</style>

      <div className={`container ${shake ? "shake" : ""}`} ref={gameRef}>

        <h1>🎮 Gradient Hunter</h1>

        <div className="stats">

          <div>Score: {score}</div>
          <div>Combo: x{combo}</div>
          <div>Level: {level}</div>
          <div>Lives: ❤️ {lives}</div>
          <div>High: {highScore}</div>

        </div>

        <div className="game">

          {orbs.map((orb) => (

            <div
              key={orb.id}
              className="orb"
              style={{
                background: orb.color.value,
                left: orb.x + "%",
                animationDuration: orb.speed + "ms",
              }}
              onAnimationEnd={() => {
                removeOrb(orb.id);
                fail();
              }}
            ></div>

          ))}

        </div>

        <div className="buttons">

          {COLORS.map((c) => (

            <button
              key={c.name}
              style={{ background: c.value }}
              onClick={() => handlePress(c.name)}
            >

              {c.name} ({c.key})

            </button>

          ))}

        </div>

        <div className="message">{message}</div>

        <div className="controls">

          <button
            style={{ background: "#22c55e" }}
            onClick={() => setPaused((p) => !p)}
          >
            {paused ? "Resume" : "Pause"}
          </button>

          <button
            style={{ background: "#ef4444" }}
            onClick={resetGame}
          >
            Restart
          </button>

        </div>

        <div className="panel">

          Keyboard Controls  
          <br />
          Q W E R T → Match Colors  
          <br />
          P → Pause Game

        </div>

      </div>
    </>
  );
}

export default GradientHunter;