function Greeting() {

    let currDate = new Date(2026, 3, 5, 12);

    currDate = currDate.getHours();
    console.log(currDate);

    let greeting = "";
    let CssStyle = {};

    if (currDate > 1 && currDate < 12) {
        greeting = "Good Morning";
        CssStyle.color = "Yellow";
    }
    else if (currDate > 1 && currDate < 12) {
        greeting = "Good Afternoon";
        CssStyle.color = "SkyBlue";


    }

    else {
        greeting = "Good Night";
        CssStyle.color = "red"
    }

    return (
        <>
            <h1>Hello Huzaifa <span style={CssStyle}>{greeting}</span></h1>
        </>
    )



}

export default Greeting;