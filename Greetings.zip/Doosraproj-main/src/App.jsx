import Changer from "./Components/Changer";
import Greeting from "./Components/Greeting";

  
function App
(){

    return(
        <>
        
        <Changer/>            
        <Greeting/>
        
        </>
    )
}

export default App;